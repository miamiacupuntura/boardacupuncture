<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026102102;
$plugin->requires  = 2022111800;
$plugin->component = 'block_menu_course';
