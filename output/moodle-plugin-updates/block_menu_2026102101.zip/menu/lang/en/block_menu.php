<?php
$string['pluginname'] = 'Menu';